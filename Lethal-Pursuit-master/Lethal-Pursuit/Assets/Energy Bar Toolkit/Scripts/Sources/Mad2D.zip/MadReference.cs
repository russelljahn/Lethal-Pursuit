/*
* Energy Bar Toolkit by Mad Pixel Machine
* http://www.madpixelmachine.com
*/

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using EnergyBarToolkit;

#if !UNITY_3_5
namespace EnergyBarToolkit {
#endif

[ExecuteInEditMode]
public class MadReference : MonoBehaviour {

    // ===========================================================
    // Constants
    // ===========================================================

    // ===========================================================
    // Fields
    // ===========================================================
    
    
    public MadSprite referencedSprite {
        get {
            return _referencedSprite;
        }
        
        set {
            if (_referencedSprite != value) {
                UnregisterSprite();
            }
            
            _referencedSprite = value;
            
            RegisterSprite();
        }
    }
    MadSprite _referencedSprite;
    
    public MadPanel parentPanel {
        get {
            if (_parentPanel == null) {
                _parentPanel = MadTransform.FindParent<MadPanel>(transform);
            }
            
            return _parentPanel;
        }
    }
    MadPanel _parentPanel;

    // ===========================================================
    // Methods for/from SuperClass/Interfaces
    // ===========================================================

    // ===========================================================
    // Methods
    // ===========================================================

    void OnEnable() {
        RegisterSprite();
    }

    void Start() {
        RegisterSprite();
    }

    void Update() {
        // if reference sprite is not set during the update, object should be removed
        // because it might mean that this object is not used anymore (from previous scene save)
        //
        // Normally I would use HideAndDontSave flag for this object, but not saving child when a parent
        // exists may cause unity to crash.
        if (referencedSprite == null) {
            MadGameObject.SafeDestroy(gameObject);
        }
    }
    
    void OnDisable() {
        UnregisterSprite();
    }
    
    void OnDestroy() {
        UnregisterSprite();
    }

    void RegisterSprite() {
        if (referencedSprite == null) {
            return;
        }
    
        var panel = parentPanel;
    
        if (panel != null) {
            panel.sprites.Add(referencedSprite);
        }
    }
    
    void UnregisterSprite() {
        if (referencedSprite == null) {
            return;
        }
    
        var panel = parentPanel;
    
        if (panel != null) {
            panel.sprites.Remove(referencedSprite);
        }
    }

    // ===========================================================
    // Static Methods
    // ===========================================================
    
    public static MadReference TryCreate() {
        var scenePanel = MadPanel.UniqueOrNull();
        
        if (scenePanel == null) {
            return null;
        }
        
        // there is a panel in this scene, create a reference
        var reference = MadTransform.CreateChild<MadReference>(scenePanel.transform, "_reference");

#if !MAD_DEBUG
        reference.gameObject.hideFlags = HideFlags.HideInHierarchy;
#endif

        return reference;
    }

    // ===========================================================
    // Inner and Anonymous Classes
    // ===========================================================

}

#if !UNITY_3_5
} // namespace
#endif